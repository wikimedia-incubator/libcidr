#!/bin/sh
exec ./mkgmake.sh rm
