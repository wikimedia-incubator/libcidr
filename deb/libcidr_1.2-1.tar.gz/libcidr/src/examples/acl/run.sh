#!/bin/sh
env LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:../../ ./acl $*
